Author: There were many. This latest version of the LuxBall was created from scratch by Rhys.
Created with LuxCoreRender v2.3
Blender file saved with Blender 2.82

How to render with luxcoreui:
* Open luxcoreui application (get from https://luxcorerender.org/download/)
* Open the menu "Rendering -> Load" on the upper left
* Navigate into this folder and open "LuxCoreScene"
* Select the file "render.cfg" and click "Open"

How to render with Blender:
* You need to have the BlendLuxCore addon installed (https://github.com/LuxCoreRender/BlendLuxCore)
* Open the .blend file and press F12